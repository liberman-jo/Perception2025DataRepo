P3 framewise distances package

Files:
- P3_all_trials_framewise_C7S2_BoxA_BoxB.csv
  Framewise distances from C7 and S2 markers to Box A and Box B centers (from box_centers.csv).
  Columns:
    Participant, TrialNum, Frame, Time,
    dist_C7_to_A, dist_S2_to_A, mean_dist_to_A,
    dist_C7_to_B, dist_S2_to_B, mean_dist_to_B,
    mean_dist_AB, VisibleMarkers (if present)

- P3_trial_summary_means_C7S2_BoxA_BoxB.csv
  Per-trial means computed from the framewise file.

Notes:
- This does NOT require box marker columns in the raw CSVs; it uses fixed box centers (same as P1.2/P2).
- Trials included: 2..37 (36 trials).
